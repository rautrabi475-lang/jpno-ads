# JPNO Ads Agency Portfolio

Open `index.html` in a browser to preview the portfolio.

## Add your real UGC videos
The three portfolio cards are placeholders. Replace each `.thumb` block with a `<video>` element pointing to your video file.

## Contact
WhatsApp: +977 9826060495
Email: jpnoadsajency@gmail.com
